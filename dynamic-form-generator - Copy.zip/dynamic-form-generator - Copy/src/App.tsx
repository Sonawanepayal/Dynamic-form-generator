import React, { useState } from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { dracula } from "react-syntax-highlighter/dist/esm/styles/prism";
import "./index.css"; // Ensure Tailwind is imported in this CSS file

const App: React.FC = () => {
  const [jsonInput, setJsonInput] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [schema, setSchema] = useState<any>(null);

  const handleJsonChange = (value: string) => {
    setJsonInput(value);
    try {
      const parsed = JSON.parse(value);
      setError(null);
      setSchema(parsed);
    } catch (err) {
      setError("Invalid JSON");
    }
  };

  const FormGenerator: React.FC<{ schema: any }> = ({ schema }) => {
    const { register, handleSubmit, formState: { errors } } = useForm();

    const onSubmit: SubmitHandler<any> = (data) => {
      console.log("Form Data:", data);
      alert("Form submitted successfully!");
    };

    if (!schema || !schema.fields) return <p>No schema provided.</p>;

    return (
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <h1 className="text-lg font-bold">{schema.formTitle}</h1>
        <p>{schema.formDescription}</p>

        {schema.fields.map((field: any) => (
          <div key={field.id} className="flex flex-col">
            <label htmlFor={field.id} className="font-semibold">{field.label}</label>
            {field.type === "text" && (
              <input
                id={field.id}
                type="text"
                placeholder={field.placeholder}
                {...register(field.id, { required: field.required })}
                className="border p-2 rounded"
              />
            )}
            {field.type === "email" && (
              <input
                id={field.id}
                type="email"
                placeholder={field.placeholder}
                {...register(field.id, { 
                  required: field.required, 
                  pattern: field.validation?.pattern && new RegExp(field.validation.pattern) 
                })}
                className="border p-2 rounded"
              />
            )}
            {field.type === "select" && (
              <select
                id={field.id}
                {...register(field.id, { required: field.required })}
                className="border p-2 rounded"
              >
                <option value="">Select...</option>
                {field.options.map((option: any) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            )}
            {field.type === "radio" && (
              <div>
                {field.options.map((option: any) => (
                  <label key={option.value} className="inline-flex items-center mr-4">
                    <input
                      type="radio"
                      value={option.value}
                      {...register(field.id, { required: field.required })}
                      className="mr-2"
                    />
                    {option.label}
                  </label>
                ))}
              </div>
            )}
            {field.type === "textarea" && (
              <textarea
                id={field.id}
                placeholder={field.placeholder}
                {...register(field.id, { required: field.required })}
                className="border p-2 rounded"
              />
            )}
            {errors[field.id] && (
              <p className="text-red-500 text-sm">
                {field.validation?.message || "This field is required"}
              </p>
            )}
          </div>
        ))}

        <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
          Submit
        </button>
      </form>
    );
  };

  return (
    <div className="flex flex-col md:flex-row h-screen">
      <div className="w-full md:w-1/2 p-4">
        <textarea
          className="w-full h-64 border rounded p-2"
          value={jsonInput}
          onChange={(e) => handleJsonChange(e.target.value)}
        />
        {error && <p className="text-red-500 text-sm">{error}</p>}
        <SyntaxHighlighter language="json" style={dracula}>
          {jsonInput}
        </SyntaxHighlighter>
      </div>
      <div className="w-full md:w-1/2 p-4 bg-gray-100">
        <FormGenerator schema={schema} />
      </div>
    </div>
  );
};

export default App;

