declare module 'react-syntax-highlighter/dist/esm/styles/prism' {
  const content: any;
  export default content;
}
